The answer of the 1st and 2nd question is in the end of the report.

Emre YILMAZ
1901042606
